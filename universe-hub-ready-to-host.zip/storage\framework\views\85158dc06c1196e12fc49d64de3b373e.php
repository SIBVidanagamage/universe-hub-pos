<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>UNIVERSE HUB</title>
    <script type="text/javascript" src="<?php echo e(asset('js/qz-tray.js')); ?>"></script>
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">

    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/index.css', 'resources/js/main.jsx']); ?>
</head>

<body>
    <div id="root"></div>
</body>

</html>
<?php /**PATH D:\universe hub poss\Mobile-Accessories-shop-system-master\Mobile-Accessories-shop-system-master\resources\views/welcome.blade.php ENDPATH**/ ?>